#!/bin/venv python3

import csv
import datetime
import json
import os
import random
import urllib.request

FEMALE_NAMES_URL = "https://raw.githubusercontent.com/datasets-io/female" \
                   "-first-names-en/master/lib/dataset.json"
MALE_NAMES_URL = "https://raw.githubusercontent.com/datasets-io/male-first" \
                 "-names-en/master/lib/dataset.json"
SURNAMES_URL = "https://raw.githubusercontent.com/fivethirtyeight/data/master" \
               "/most-common-name/surnames.csv"
# Number of random female/male names to generate
NUM_FEMALES = 10000
NUM_MALES = 10000


def get_firstnames(url: str) -> list:
    with urllib.request.urlopen(url) as req:
        jobj = json.loads(req.read())
        return list(jobj)


female_firstnames = get_firstnames(FEMALE_NAMES_URL)
male_firstnames = get_firstnames(MALE_NAMES_URL)

# Get lastnames
lastnames = []
chunk_size = 1024 ** 2  # 1 MB
if not os.path.isfile("lastnames.csv"):
    with urllib.request.urlopen(SURNAMES_URL) as req, \
            open("lastnames.csv", "bw") as outf:
        # Download chunk by chunk to avoid out-of-memory
        buf = req.read(chunk_size)
        while buf:
            outf.write(buf)
            buf = req.read(chunk_size)
with open("lastnames.csv", "r") as f:
    csv_rdr = csv.reader(f, delimiter=",")
    next(csv_rdr)  # Skip header row
    for row in csv_rdr:
        lastname = row[0].capitalize()
        lastnames.append(lastname)

start_date = datetime.date(1970, 1, 1)
end_date = datetime.date(2003, 12, 31)
time_between_dates = end_date - start_date
days_between_dates = time_between_dates.days


def random_dob() -> str:
    r_days = random.randrange(days_between_dates)
    r_date = start_date + datetime.timedelta(days=r_days)
    return r_date.strftime("%Y-%m-%d")


def random_gpa() -> str:
    return "{:.2f}".format(random.uniform(2.0, 4.0))


with open("names.csv", "w") as outf:
    female_remains = NUM_FEMALES
    male_remains = NUM_MALES
    for uid in range(1, NUM_FEMALES + NUM_MALES + 1):
        # Random lastname
        r_lastname = random.choice(lastnames)
        if female_remains > 0 and male_remains > 0:
            is_female = random.randint(0, 1) == 0
        elif female_remains > 0:
            is_female = True
        else:
            is_female = False
        if is_female:
            r_firstname = random.choice(female_firstnames)
            sex = 0
            female_remains -= 1
        else:
            r_firstname = random.choice(male_firstnames)
            sex = 1
            male_remains -= 1
        # Lower case letter for case insensitive search
        outf.write(f"{uid},"
                   f"{sex},"
                   f"{r_lastname},{r_lastname.lower()},"
                   f"{r_firstname},{r_firstname.lower()},"
                   f"{random_dob()},"
                   f"{random_gpa()}\n")
